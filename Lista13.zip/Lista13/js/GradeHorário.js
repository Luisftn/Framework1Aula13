$(function() {
    setInterval(function() {
        $('h1').fadeOut(3000);
        $('h1').fadeIn(3000);
    });
});    